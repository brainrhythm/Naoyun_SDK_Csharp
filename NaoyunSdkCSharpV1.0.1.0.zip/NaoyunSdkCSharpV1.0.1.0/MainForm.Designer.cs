namespace NaoyunSdkSample
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.menuItemView = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemEegWaveform = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.menuItemAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.grpConnectionType = new System.Windows.Forms.GroupBox();
            this.rbBle = new System.Windows.Forms.RadioButton();
            this.grpDevice = new System.Windows.Forms.GroupBox();
            this.btnScan = new System.Windows.Forms.Button();
            this.btnStopScan = new System.Windows.Forms.Button();
            this.lstDevices = new System.Windows.Forms.ListBox();
            this.grpConnection = new System.Windows.Forms.GroupBox();
            this.btnDisconnect = new System.Windows.Forms.Button();
            this.btnConnect = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.grpReadWrite = new System.Windows.Forms.GroupBox();
            this.btnNoiseReductionOff = new System.Windows.Forms.Button();
            this.btnEnvironmentalSound = new System.Windows.Forms.Button();
            this.btnNoiseReductionOn = new System.Windows.Forms.Button();
            this.btnTouchOn = new System.Windows.Forms.Button();
            this.btnTouchOff = new System.Windows.Forms.Button();
            this.btnAutoPlayOn = new System.Windows.Forms.Button();
            this.btnAutoPlayOff = new System.Windows.Forms.Button();
            this.btnStartData = new System.Windows.Forms.Button();
            this.btnStopData = new System.Windows.Forms.Button();
            this.btnStartRecording = new System.Windows.Forms.Button();
            this.btnStopRecording = new System.Windows.Forms.Button();
            this.lblRecordingDuration = new System.Windows.Forms.Label();
            this.grpLog = new System.Windows.Forms.GroupBox();
            this.txtLog = new System.Windows.Forms.TextBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsslEarSide = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslLeftBattery = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslRightBattery = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslLeftWorn = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslRightWorn = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslVersion = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslNoiseReduction = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslTouch = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslAutoPlay = new System.Windows.Forms.ToolStripStatusLabel();
            this.menuStrip1.SuspendLayout();
            this.grpConnectionType.SuspendLayout();
            this.grpDevice.SuspendLayout();
            this.grpConnection.SuspendLayout();
            this.grpReadWrite.SuspendLayout();
            this.grpLog.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemView,
            this.menuItemHelp});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1080, 32);
            this.menuStrip1.TabIndex = 100;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // menuItemView
            // 
            this.menuItemView.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemEegWaveform});
            this.menuItemView.Name = "menuItemView";
            this.menuItemView.Size = new System.Drawing.Size(67, 28);
            this.menuItemView.Text = "View";
            // 
            // menuItemEegWaveform
            // 
            this.menuItemEegWaveform.Name = "menuItemEegWaveform";
            this.menuItemEegWaveform.Size = new System.Drawing.Size(236, 34);
            this.menuItemEegWaveform.Text = "EEG Waveform";
            this.menuItemEegWaveform.Click += new System.EventHandler(this.MenuItemEegWaveform_Click);
            // 
            // menuItemHelp
            // 
            this.menuItemHelp.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuItemAbout});
            this.menuItemHelp.Name = "menuItemHelp";
            this.menuItemHelp.Size = new System.Drawing.Size(67, 28);
            this.menuItemHelp.Text = "Help";
            // 
            // menuItemAbout
            // 
            this.menuItemAbout.Name = "menuItemAbout";
            this.menuItemAbout.Size = new System.Drawing.Size(204, 34);
            this.menuItemAbout.Text = "About SDK";
            this.menuItemAbout.Click += new System.EventHandler(this.MenuItemAbout_Click);
            // 
            // grpConnectionType
            // 
            this.grpConnectionType.Controls.Add(this.rbBle);
            this.grpConnectionType.Location = new System.Drawing.Point(20, 43);
            this.grpConnectionType.Name = "grpConnectionType";
            this.grpConnectionType.Size = new System.Drawing.Size(300, 60);
            this.grpConnectionType.TabIndex = 0;
            this.grpConnectionType.TabStop = false;
            this.grpConnectionType.Text = "Connection Type";
            // 
            // rbBle
            // 
            this.rbBle.AutoSize = true;
            this.rbBle.Checked = true;
            this.rbBle.Location = new System.Drawing.Point(20, 25);
            this.rbBle.Name = "rbBle";
            this.rbBle.Size = new System.Drawing.Size(65, 28);
            this.rbBle.TabIndex = 0;
            this.rbBle.TabStop = true;
            this.rbBle.Text = "BLE";
            this.rbBle.UseVisualStyleBackColor = true;
            // 
            // grpDevice
            // 
            this.grpDevice.Controls.Add(this.btnScan);
            this.grpDevice.Controls.Add(this.btnStopScan);
            this.grpDevice.Controls.Add(this.lstDevices);
            this.grpDevice.Location = new System.Drawing.Point(20, 118);
            this.grpDevice.Name = "grpDevice";
            this.grpDevice.Size = new System.Drawing.Size(300, 400);
            this.grpDevice.TabIndex = 1;
            this.grpDevice.TabStop = false;
            this.grpDevice.Text = "Device List";
            // 
            // btnScan
            // 
            this.btnScan.Location = new System.Drawing.Point(15, 25);
            this.btnScan.Name = "btnScan";
            this.btnScan.Size = new System.Drawing.Size(130, 35);
            this.btnScan.TabIndex = 0;
            this.btnScan.Text = "Scan Devices";
            this.btnScan.UseVisualStyleBackColor = true;
            this.btnScan.Click += new System.EventHandler(this.BtnScan_Click);
            // 
            // btnStopScan
            // 
            this.btnStopScan.Enabled = false;
            this.btnStopScan.Location = new System.Drawing.Point(155, 25);
            this.btnStopScan.Name = "btnStopScan";
            this.btnStopScan.Size = new System.Drawing.Size(130, 35);
            this.btnStopScan.TabIndex = 1;
            this.btnStopScan.Text = "Stop Scan";
            this.btnStopScan.UseVisualStyleBackColor = true;
            this.btnStopScan.Click += new System.EventHandler(this.BtnStopScan_Click);
            // 
            // lstDevices
            // 
            this.lstDevices.FormattingEnabled = true;
            this.lstDevices.HorizontalScrollbar = true;
            this.lstDevices.ItemHeight = 24;
            this.lstDevices.Location = new System.Drawing.Point(15, 70);
            this.lstDevices.Name = "lstDevices";
            this.lstDevices.Size = new System.Drawing.Size(270, 316);
            this.lstDevices.TabIndex = 1;
            this.lstDevices.SelectedIndexChanged += new System.EventHandler(this.LstDevices_SelectedIndexChanged);
            // 
            // grpConnection
            // 
            this.grpConnection.Controls.Add(this.btnDisconnect);
            this.grpConnection.Controls.Add(this.btnConnect);
            this.grpConnection.Controls.Add(this.lblStatus);
            this.grpConnection.Location = new System.Drawing.Point(346, 43);
            this.grpConnection.Name = "grpConnection";
            this.grpConnection.Size = new System.Drawing.Size(300, 130);
            this.grpConnection.TabIndex = 2;
            this.grpConnection.TabStop = false;
            this.grpConnection.Text = "Connection Management";
            // 
            // btnDisconnect
            // 
            this.btnDisconnect.Enabled = false;
            this.btnDisconnect.Location = new System.Drawing.Point(155, 30);
            this.btnDisconnect.Name = "btnDisconnect";
            this.btnDisconnect.Size = new System.Drawing.Size(130, 35);
            this.btnDisconnect.TabIndex = 2;
            this.btnDisconnect.Text = "Disconnect";
            this.btnDisconnect.UseVisualStyleBackColor = true;
            this.btnDisconnect.Click += new System.EventHandler(this.BtnDisconnect_Click);
            // 
            // btnConnect
            // 
            this.btnConnect.Enabled = false;
            this.btnConnect.Location = new System.Drawing.Point(15, 30);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(130, 35);
            this.btnConnect.TabIndex = 1;
            this.btnConnect.Text = "Connect Device";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.BtnConnect_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblStatus.Location = new System.Drawing.Point(15, 75);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(270, 40);
            this.lblStatus.TabIndex = 0;
            this.lblStatus.Text = "Status: Disconnected";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // grpReadWrite
            // 
            this.grpReadWrite.Controls.Add(this.btnNoiseReductionOff);
            this.grpReadWrite.Controls.Add(this.btnEnvironmentalSound);
            this.grpReadWrite.Controls.Add(this.btnNoiseReductionOn);
            this.grpReadWrite.Controls.Add(this.btnTouchOn);
            this.grpReadWrite.Controls.Add(this.btnTouchOff);
            this.grpReadWrite.Controls.Add(this.btnAutoPlayOn);
            this.grpReadWrite.Controls.Add(this.btnAutoPlayOff);
            this.grpReadWrite.Controls.Add(this.btnStartData);
            this.grpReadWrite.Controls.Add(this.btnStopData);
            this.grpReadWrite.Controls.Add(this.btnStartRecording);
            this.grpReadWrite.Controls.Add(this.btnStopRecording);
            this.grpReadWrite.Controls.Add(this.lblRecordingDuration);
            this.grpReadWrite.Location = new System.Drawing.Point(340, 197);
            this.grpReadWrite.Name = "grpReadWrite";
            this.grpReadWrite.Size = new System.Drawing.Size(314, 321);
            this.grpReadWrite.TabIndex = 4;
            this.grpReadWrite.TabStop = false;
            this.grpReadWrite.Text = "Device Control";
            // 
            // btnNoiseReductionOff
            // 
            this.btnNoiseReductionOff.Enabled = false;
            this.btnNoiseReductionOff.Location = new System.Drawing.Point(15, 161);
            this.btnNoiseReductionOff.Name = "btnNoiseReductionOff";
            this.btnNoiseReductionOff.Size = new System.Drawing.Size(130, 32);
            this.btnNoiseReductionOff.TabIndex = 6;
            this.btnNoiseReductionOff.Text = "Normal";
            this.btnNoiseReductionOff.UseVisualStyleBackColor = true;
            this.btnNoiseReductionOff.Click += new System.EventHandler(this.BtnNoiseReductionOff_Click);
            // 
            // btnEnvironmentalSound
            // 
            this.btnEnvironmentalSound.Enabled = false;
            this.btnEnvironmentalSound.Location = new System.Drawing.Point(15, 199);
            this.btnEnvironmentalSound.Name = "btnEnvironmentalSound";
            this.btnEnvironmentalSound.Size = new System.Drawing.Size(285, 32);
            this.btnEnvironmentalSound.TabIndex = 8;
            this.btnEnvironmentalSound.Text = "Environmental Sound";
            this.btnEnvironmentalSound.UseVisualStyleBackColor = true;
            this.btnEnvironmentalSound.Click += new System.EventHandler(this.BtnEnvironmentalSound_Click);
            // 
            // btnNoiseReductionOn
            // 
            this.btnNoiseReductionOn.Enabled = false;
            this.btnNoiseReductionOn.Location = new System.Drawing.Point(164, 161);
            this.btnNoiseReductionOn.Name = "btnNoiseReductionOn";
            this.btnNoiseReductionOn.Size = new System.Drawing.Size(136, 32);
            this.btnNoiseReductionOn.TabIndex = 7;
            this.btnNoiseReductionOn.Text = "Noise Reduction";
            this.btnNoiseReductionOn.UseVisualStyleBackColor = true;
            this.btnNoiseReductionOn.Click += new System.EventHandler(this.BtnNoiseReductionOn_Click);
            // 
            // btnTouchOn
            // 
            this.btnTouchOn.Enabled = false;
            this.btnTouchOn.Location = new System.Drawing.Point(15, 237);
            this.btnTouchOn.Name = "btnTouchOn";
            this.btnTouchOn.Size = new System.Drawing.Size(130, 32);
            this.btnTouchOn.TabIndex = 9;
            this.btnTouchOn.Text = "Touch On";
            this.btnTouchOn.UseVisualStyleBackColor = true;
            this.btnTouchOn.Click += new System.EventHandler(this.BtnTouchOn_Click);
            // 
            // btnTouchOff
            // 
            this.btnTouchOff.Enabled = false;
            this.btnTouchOff.Location = new System.Drawing.Point(164, 237);
            this.btnTouchOff.Name = "btnTouchOff";
            this.btnTouchOff.Size = new System.Drawing.Size(136, 32);
            this.btnTouchOff.TabIndex = 10;
            this.btnTouchOff.Text = "Touch Off";
            this.btnTouchOff.UseVisualStyleBackColor = true;
            this.btnTouchOff.Click += new System.EventHandler(this.BtnTouchOff_Click);
            // 
            // btnAutoPlayOn
            // 
            this.btnAutoPlayOn.Enabled = false;
            this.btnAutoPlayOn.Location = new System.Drawing.Point(15, 275);
            this.btnAutoPlayOn.Name = "btnAutoPlayOn";
            this.btnAutoPlayOn.Size = new System.Drawing.Size(130, 32);
            this.btnAutoPlayOn.TabIndex = 11;
            this.btnAutoPlayOn.Text = "Auto Play On";
            this.btnAutoPlayOn.UseVisualStyleBackColor = true;
            this.btnAutoPlayOn.Click += new System.EventHandler(this.BtnAutoPlayOn_Click);
            // 
            // btnAutoPlayOff
            // 
            this.btnAutoPlayOff.Enabled = false;
            this.btnAutoPlayOff.Location = new System.Drawing.Point(164, 275);
            this.btnAutoPlayOff.Name = "btnAutoPlayOff";
            this.btnAutoPlayOff.Size = new System.Drawing.Size(136, 32);
            this.btnAutoPlayOff.TabIndex = 12;
            this.btnAutoPlayOff.Text = "Auto Play Off";
            this.btnAutoPlayOff.UseVisualStyleBackColor = true;
            this.btnAutoPlayOff.Click += new System.EventHandler(this.BtnAutoPlayOff_Click);
            // 
            // btnStartData
            // 
            this.btnStartData.Enabled = false;
            this.btnStartData.Location = new System.Drawing.Point(15, 30);
            this.btnStartData.Name = "btnStartData";
            this.btnStartData.Size = new System.Drawing.Size(100, 32);
            this.btnStartData.TabIndex = 2;
            this.btnStartData.Text = "Start Data";
            this.btnStartData.UseVisualStyleBackColor = true;
            this.btnStartData.Click += new System.EventHandler(this.BtnStartData_Click);
            // 
            // btnStopData
            // 
            this.btnStopData.Enabled = false;
            this.btnStopData.Location = new System.Drawing.Point(120, 30);
            this.btnStopData.Name = "btnStopData";
            this.btnStopData.Size = new System.Drawing.Size(100, 32);
            this.btnStopData.TabIndex = 3;
            this.btnStopData.Text = "Stop Data";
            this.btnStopData.UseVisualStyleBackColor = true;
            this.btnStopData.Click += new System.EventHandler(this.BtnStopData_Click);
            // 
            // btnStartRecording
            // 
            this.btnStartRecording.Enabled = false;
            this.btnStartRecording.Location = new System.Drawing.Point(15, 70);
            this.btnStartRecording.Name = "btnStartRecording";
            this.btnStartRecording.Size = new System.Drawing.Size(130, 32);
            this.btnStartRecording.TabIndex = 4;
            this.btnStartRecording.Text = "start record";
            this.btnStartRecording.UseVisualStyleBackColor = true;
            this.btnStartRecording.Click += new System.EventHandler(this.BtnStartRecording_Click);
            // 
            // btnStopRecording
            // 
            this.btnStopRecording.Enabled = false;
            this.btnStopRecording.Location = new System.Drawing.Point(164, 70);
            this.btnStopRecording.Name = "btnStopRecording";
            this.btnStopRecording.Size = new System.Drawing.Size(136, 32);
            this.btnStopRecording.TabIndex = 5;
            this.btnStopRecording.Text = "Stop Record";
            this.btnStopRecording.UseVisualStyleBackColor = true;
            this.btnStopRecording.Click += new System.EventHandler(this.BtnStopRecording_Click);
            // 
            // lblRecordingDuration
            // 
            this.lblRecordingDuration.Font = new System.Drawing.Font("Consolas", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRecordingDuration.ForeColor = System.Drawing.Color.Black;
            this.lblRecordingDuration.Location = new System.Drawing.Point(15, 104);
            this.lblRecordingDuration.Name = "lblRecordingDuration";
            this.lblRecordingDuration.Size = new System.Drawing.Size(130, 25);
            this.lblRecordingDuration.TabIndex = 9;
            this.lblRecordingDuration.Text = "00:00:00";
            // 
            // grpLog
            // 
            this.grpLog.Controls.Add(this.txtLog);
            this.grpLog.Location = new System.Drawing.Point(680, 43);
            this.grpLog.Name = "grpLog";
            this.grpLog.Size = new System.Drawing.Size(375, 475);
            this.grpLog.TabIndex = 5;
            this.grpLog.TabStop = false;
            this.grpLog.Text = "Log";
            // 
            // txtLog
            // 
            this.txtLog.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtLog.Location = new System.Drawing.Point(3, 27);
            this.txtLog.Multiline = true;
            this.txtLog.Name = "txtLog";
            this.txtLog.ReadOnly = true;
            this.txtLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtLog.Size = new System.Drawing.Size(369, 445);
            this.txtLog.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslEarSide,
            this.tsslLeftBattery,
            this.tsslRightBattery,
            this.tsslLeftWorn,
            this.tsslRightWorn,
            this.tsslVersion,
            this.tsslNoiseReduction,
            this.tsslTouch,
            this.tsslAutoPlay});
            this.statusStrip1.Location = new System.Drawing.Point(0, 531);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1080, 31);
            this.statusStrip1.TabIndex = 101;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsslEarSide
            // 
            this.tsslEarSide.Name = "tsslEarSide";
            this.tsslEarSide.Size = new System.Drawing.Size(72, 24);
            this.tsslEarSide.Text = "Conn: -";
            // 
            // tsslLeftBattery
            // 
            this.tsslLeftBattery.Name = "tsslLeftBattery";
            this.tsslLeftBattery.Size = new System.Drawing.Size(76, 24);
            this.tsslLeftBattery.Text = "L Batt: -";
            // 
            // tsslRightBattery
            // 
            this.tsslRightBattery.Name = "tsslRightBattery";
            this.tsslRightBattery.Size = new System.Drawing.Size(79, 24);
            this.tsslRightBattery.Text = "R Batt: -";
            // 
            // tsslLeftWorn
            // 
            this.tsslLeftWorn.Name = "tsslLeftWorn";
            this.tsslLeftWorn.Size = new System.Drawing.Size(88, 24);
            this.tsslLeftWorn.Text = "L Worn: -";
            // 
            // tsslRightWorn
            // 
            this.tsslRightWorn.Name = "tsslRightWorn";
            this.tsslRightWorn.Size = new System.Drawing.Size(91, 24);
            this.tsslRightWorn.Text = "R Worn: -";
            // 
            // tsslVersion
            // 
            this.tsslVersion.Name = "tsslVersion";
            this.tsslVersion.Size = new System.Drawing.Size(56, 24);
            this.tsslVersion.Text = "Ver: -";
            // 
            // tsslNoiseReduction
            // 
            this.tsslNoiseReduction.Name = "tsslNoiseReduction";
            this.tsslNoiseReduction.Size = new System.Drawing.Size(54, 24);
            this.tsslNoiseReduction.Text = "NR: -";
            // 
            // tsslTouch
            // 
            this.tsslTouch.Name = "tsslTouch";
            this.tsslTouch.Size = new System.Drawing.Size(79, 24);
            this.tsslTouch.Text = "Touch: -";
            // 
            // tsslAutoPlay
            // 
            this.tsslAutoPlay.Name = "tsslAutoPlay";
            this.tsslAutoPlay.Size = new System.Drawing.Size(69, 24);
            this.tsslAutoPlay.Text = "Auto: -";
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1080, 562);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.grpLog);
            this.Controls.Add(this.grpReadWrite);
            this.Controls.Add(this.grpConnection);
            this.Controls.Add(this.grpDevice);
            this.Controls.Add(this.grpConnectionType);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Naoyun SDK Sample";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.MainForm_FormClosing);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.grpConnectionType.ResumeLayout(false);
            this.grpConnectionType.PerformLayout();
            this.grpDevice.ResumeLayout(false);
            this.grpConnection.ResumeLayout(false);
            this.grpReadWrite.ResumeLayout(false);
            this.grpLog.ResumeLayout(false);
            this.grpLog.PerformLayout();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpConnectionType;
        private System.Windows.Forms.RadioButton rbBle;
        private System.Windows.Forms.GroupBox grpDevice;
        private System.Windows.Forms.Button btnScan;
        private System.Windows.Forms.Button btnStopScan;
        private System.Windows.Forms.ListBox lstDevices;
        private System.Windows.Forms.GroupBox grpConnection;
        private System.Windows.Forms.Button btnDisconnect;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.GroupBox grpReadWrite;
        private System.Windows.Forms.Button btnStartRecording;
        private System.Windows.Forms.Button btnStopRecording;
        private System.Windows.Forms.Label lblRecordingDuration;
        private System.Windows.Forms.GroupBox grpLog;
        private System.Windows.Forms.TextBox txtLog;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuItemView;
        private System.Windows.Forms.ToolStripMenuItem menuItemEegWaveform;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsslLeftBattery;
        private System.Windows.Forms.ToolStripStatusLabel tsslRightBattery;
        private System.Windows.Forms.ToolStripStatusLabel tsslLeftWorn;
        private System.Windows.Forms.ToolStripStatusLabel tsslRightWorn;
        private System.Windows.Forms.ToolStripStatusLabel tsslVersion;
        private System.Windows.Forms.ToolStripStatusLabel tsslNoiseReduction;
        private System.Windows.Forms.Button btnNoiseReductionOff;
        private System.Windows.Forms.Button btnNoiseReductionOn;
        private System.Windows.Forms.Button btnEnvironmentalSound;
        private System.Windows.Forms.Button btnTouchOn;
        private System.Windows.Forms.Button btnTouchOff;
        private System.Windows.Forms.Button btnAutoPlayOn;
        private System.Windows.Forms.Button btnAutoPlayOff;
        private System.Windows.Forms.ToolStripMenuItem menuItemHelp;
        private System.Windows.Forms.ToolStripMenuItem menuItemAbout;
        private System.Windows.Forms.ToolStripStatusLabel tsslEarSide;
        private System.Windows.Forms.ToolStripStatusLabel tsslTouch;
        private System.Windows.Forms.ToolStripStatusLabel tsslAutoPlay;
    }
}