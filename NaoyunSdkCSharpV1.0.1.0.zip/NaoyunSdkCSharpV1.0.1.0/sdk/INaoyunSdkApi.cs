using System;
using System.Threading.Tasks;

namespace NaoyunSdk.Interfaces
{
    public enum ConnectionType
    {
        BLE,
    }

    public enum EarSide
    {
        Left = 0x00,
        Right = 0x01
    }

    public enum SignalQuality
    {
        OK = 0,
        SizeError = 1,
        OriginalMaxValue = 2,
        OriginalZeroValue = 3,
        FilteredMaxValue = 4,
        FilteredZeroValue = 5,
        ThresholdError = 6,
        PowerFrequencyError = 7,
        OtherError = 8
    }

    public class DataReceivedEventArgs : EventArgs
    {
        public EarSide EarSide { get; private set; }
        public float[] Data { get; private set; }
        internal byte LeadOffDetection { get; private set; }
        public byte PacketCounter { get; private set; }
        public bool IsValid { get; private set; }
        public string ErrorMessage { get; private set; }
        public DateTime Timestamp { get; private set; }
        public byte[] RawData { get; private set; }

        public DataReceivedEventArgs(EarSide earSide, float[] data,
            byte leadOffDetection, byte packetCounter, bool isValid, string errorMessage = null, byte[] rawData = null)
        {
            EarSide = earSide;
            Data = data;
            LeadOffDetection = leadOffDetection;
            PacketCounter = packetCounter;
            IsValid = isValid;
            ErrorMessage = errorMessage;
            Timestamp = DateTime.Now;
            RawData = rawData;
        }
    }

    public class DeviceStateEventArgs : EventArgs
    {
        public ConnectionType ConnectionType { get; private set; }
        public bool IsConnected { get; private set; }
        public string Message { get; private set; }

        public DeviceStateEventArgs(ConnectionType connectionType, bool isConnected, string message = null)
        {
            ConnectionType = connectionType;
            IsConnected = isConnected;
            Message = message;
        }
    }

    public class DeviceStatusNotificationEventArgs : EventArgs
    {
        internal ushort Command { get; private set; }
        public byte EarSide { get; private set; }
        public byte LeftBattery { get; private set; }
        public byte RightBattery { get; private set; }
        public bool LeftWorn { get; private set; }
        public bool RightWorn { get; private set; }
        public byte HardwareVersion { get; private set; }
        public byte SoftwareVersion { get; private set; }
        internal bool IsBigEndian { get; private set; }
        public byte NoiseReductionMode { get; private set; }
        public bool TouchEnabled { get; private set; }
        public bool AutoPlayStopEnabled { get; private set; }
        public bool IsValid { get; private set; }
        public string ErrorMessage { get; private set; }
        public DateTime Timestamp { get; private set; }

        public DeviceStatusNotificationEventArgs(
            ushort command, byte earSide, byte leftBattery, byte rightBattery,
            bool leftWorn, bool rightWorn, byte hardwareVersion, byte softwareVersion,
            bool isBigEndian, byte noiseReductionMode, bool touchEnabled,
            bool autoPlayStopEnabled, bool isValid, string errorMessage = null)
        {
            Command = command;
            EarSide = earSide;
            LeftBattery = leftBattery;
            RightBattery = rightBattery;
            LeftWorn = leftWorn;
            RightWorn = rightWorn;
            HardwareVersion = hardwareVersion;
            SoftwareVersion = softwareVersion;
            IsBigEndian = isBigEndian;
            NoiseReductionMode = noiseReductionMode;
            TouchEnabled = touchEnabled;
            AutoPlayStopEnabled = autoPlayStopEnabled;
            IsValid = isValid;
            ErrorMessage = errorMessage;
            Timestamp = DateTime.Now;
        }
    }

    public class SpectrumDataEventArgs : EventArgs
    {
        public double[] LeftDelta { get; private set; }
        public double[] LeftTheta { get; private set; }
        public double[] LeftAlpha { get; private set; }
        public double[] LeftBeta { get; private set; }
        public double[] LeftGamma { get; private set; }
        public double[] LeftLowAlpha { get; private set; }
        public double[] LeftHighAlpha { get; private set; }
        public double[] LeftLowBeta { get; private set; }
        public double[] LeftHighBeta { get; private set; }
        public double[] LeftLowGamma { get; private set; }
        public double[] LeftHighGamma { get; private set; }
        public double[] RightDelta { get; private set; }
        public double[] RightTheta { get; private set; }
        public double[] RightAlpha { get; private set; }
        public double[] RightBeta { get; private set; }
        public double[] RightGamma { get; private set; }
        public double[] RightLowAlpha { get; private set; }
        public double[] RightHighAlpha { get; private set; }
        public double[] RightLowBeta { get; private set; }
        public double[] RightHighBeta { get; private set; }
        public double[] RightLowGamma { get; private set; }
        public double[] RightHighGamma { get; private set; }
        public SignalQuality LeftSignalQuality { get; private set; }
        public SignalQuality RightSignalQuality { get; private set; }
        public DateTime Timestamp { get; private set; }

        public SpectrumDataEventArgs(
            double[] leftDelta, double[] leftTheta, double[] leftAlpha, double[] leftBeta, double[] leftGamma,
            double[] leftLowAlpha, double[] leftHighAlpha, double[] leftLowBeta, double[] leftHighBeta, double[] leftLowGamma, double[] leftHighGamma,
            double[] rightDelta, double[] rightTheta, double[] rightAlpha, double[] rightBeta, double[] rightGamma,
            double[] rightLowAlpha, double[] rightHighAlpha, double[] rightLowBeta, double[] rightHighBeta, double[] rightLowGamma, double[] rightHighGamma,
            SignalQuality leftSignalQuality, SignalQuality rightSignalQuality)
        {
            LeftDelta = leftDelta;
            LeftTheta = leftTheta;
            LeftAlpha = leftAlpha;
            LeftBeta = leftBeta;
            LeftGamma = leftGamma;
            LeftLowAlpha = leftLowAlpha;
            LeftHighAlpha = leftHighAlpha;
            LeftLowBeta = leftLowBeta;
            LeftHighBeta = leftHighBeta;
            LeftLowGamma = leftLowGamma;
            LeftHighGamma = leftHighGamma;
            RightDelta = rightDelta;
            RightTheta = rightTheta;
            RightAlpha = rightAlpha;
            RightBeta = rightBeta;
            RightGamma = rightGamma;
            RightLowAlpha = rightLowAlpha;
            RightHighAlpha = rightHighAlpha;
            RightLowBeta = rightLowBeta;
            RightHighBeta = rightHighBeta;
            RightLowGamma = rightLowGamma;
            RightHighGamma = rightHighGamma;
            LeftSignalQuality = leftSignalQuality;
            RightSignalQuality = rightSignalQuality;
            Timestamp = DateTime.Now;
        }
    }

    public class SpectrumTaskStatusEventArgs : EventArgs
    {
        public bool IsRunning { get; private set; }
        public bool IsSuccess { get; private set; }
        public string Message { get; private set; }
        public DateTime Timestamp { get; private set; }

        public SpectrumTaskStatusEventArgs(bool isRunning, bool isSuccess, string message = null)
        {
            IsRunning = isRunning;
            IsSuccess = isSuccess;
            Message = message;
            Timestamp = DateTime.Now;
        }
    }

    public class MentalStateDataEventArgs : EventArgs
    {
        public double Focus { get; private set; }
        public double Fatigue { get; private set; }
        public double Relax { get; private set; }
        public double Calm { get; private set; }
        public double Stress { get; private set; }
        public DateTime Timestamp { get; private set; }

        public MentalStateDataEventArgs(double focus, double fatigue, double relax, double calm, double stress)
        {
            Focus = focus;
            Fatigue = fatigue;
            Relax = relax;
            Calm = calm;
            Stress = stress;
            Timestamp = DateTime.Now;
        }
    }

    public class BleDeviceInfo
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public ulong BluetoothAddress { get; set; }
        public bool IsConnected { get; set; }

        public override string ToString()
        {
            return string.IsNullOrEmpty(Name) ? string.Format("Unknown ({0:X12})", BluetoothAddress) : string.Format("{0} ({1:X12})", Name, BluetoothAddress);
        }
    }

    public interface INaoyunSdkApi : IDisposable
    {
        ConnectionType CurrentConnectionType { get; }
        bool IsConnected { get; }

        event EventHandler<DeviceStateEventArgs> ConnectionStateChanged;
        event EventHandler<DataReceivedEventArgs> DataReceived;
        event EventHandler<DeviceStatusNotificationEventArgs> DeviceStatusNotificationReceived;
        event EventHandler<SpectrumDataEventArgs> SpectrumDataReceived;
        event EventHandler<SpectrumTaskStatusEventArgs> SpectrumTaskStatusChanged;
        event EventHandler<MentalStateDataEventArgs> MentalStateDataReceived;
        event EventHandler<BleDeviceInfo> BleDeviceDiscovered;
        event EventHandler<Net.ServerAuthResultEventArgs> ServerAuthCompleted;

        Task<bool> ConnectBleAsync(ulong bluetoothAddress);
        Task DisconnectAsync();
        string GetSdkVersion();
        Task<bool> SendInitCommandAsync();
        Task<bool> SendStartDataAsync();
        Task<bool> SendStopDataAsync();
        Task<bool> SetNoiseReductionModeAsync(byte mode);
        Task<bool> SetTouchEnabledAsync(bool enabled);
        Task<bool> SetAutoPlayEnabledAsync(bool enabled);
        Task StartBleScanAsync(TimeSpan duration);
        void StopBleScanAsync();
        bool StartMentalStateTask(double intervalSeconds);
        void StopMentalStateTask();
        float[] GetLatestEegData(EarSide earSide, int seconds, bool useFiltered = false);
        byte[] GetLatestRawEegData(EarSide earSide, int seconds);
        bool Initialize(string serverId = null, string serverSecret = null, bool isDomestic = false);
        bool IsInitialized { get; }
        string GetFilterLastError();
        bool DebugLogEnabled { get; set; }
    }
}
