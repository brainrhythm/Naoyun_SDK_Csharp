using System;
using System.Windows.Forms;
using NaoyunSdk.Interfaces;
using ScottPlot;
using System.Collections.Generic;

namespace NaoyunSdkSample
{
    /// <summary>
    /// Form for displaying EEG waveforms and spectrum data
    /// </summary>
    public partial class EegWaveformForm : Form
    {
        /// <summary>
        /// SDK API instance
        /// </summary>
        private readonly INaoyunSdkApi _sdkApi;
        /// <summary>
        /// Timer for refreshing plots
        /// </summary>
        private readonly Timer _refreshTimer;
        /// <summary>
        /// Number of seconds to display
        /// </summary>
        private readonly int _displaySeconds;
        /// <summary>
        /// Sampling rate (Hz)
        /// </summary>
        private readonly int _sampleRate;
        /// <summary>
        /// Number of points to display
        /// </summary>
        private readonly int _displayPoints;
        /// <summary>
        /// Whether to use filtered data
        /// </summary>
        private bool _useFilteredData;
        /// <summary>
        /// Whether refresh is paused
        /// </summary>
        private bool _isPaused;

        /// <summary>
        /// Spectrum related variables
        /// </summary>
        private const int SPECTRUM_HISTORY_SECONDS = 60; // Display 60 seconds of spectrum history
        private double[][] _leftSpectrumData = new double[SPECTRUM_HISTORY_SECONDS][]; // Store left ear spectrum data [theta, alpha, beta, gamma]
        private double[][] _rightSpectrumData = new double[SPECTRUM_HISTORY_SECONDS][]; // Store right ear spectrum data [theta, alpha, beta, gamma]
        private int _currentIndex = 0; // Current index for spectrum data

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="sdkApi">SDK API instance</param>
        /// <param name="displaySeconds">Number of seconds to display (default: 30)</param>
        public EegWaveformForm(INaoyunSdkApi sdkApi, int displaySeconds = 30)
        {
            _sdkApi = sdkApi;
            _displaySeconds = displaySeconds;
            _sampleRate = 500;
            _displayPoints = _displaySeconds * _sampleRate;
            _useFilteredData = true; // Enable filtering by default
            _isPaused = false;

            InitializeComponent();

            chkFilter.Checked = true; // Enable filtering by default
            _refreshTimer = new Timer();
            _refreshTimer.Interval = 100;
            _refreshTimer.Tick += RefreshTimer_Tick;

            SetupPlots();
            UpdateFilterControls();

            // Subscribe to spectrum data events
            _sdkApi.SpectrumDataReceived += SdkApi_SpectrumDataReceived;
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EegWaveformForm));
            this.formsPlotWaveform = new ScottPlot.WinForms.FormsPlot();
            this.formsPlotLeftSpectrum = new ScottPlot.WinForms.FormsPlot();
            this.formsPlotRightSpectrum = new ScottPlot.WinForms.FormsPlot();
            this.panelControls = new System.Windows.Forms.Panel();
            this.lblFilterStatus = new System.Windows.Forms.Label();
            this.chkFilter = new System.Windows.Forms.CheckBox();
            this.btnPause = new System.Windows.Forms.Button();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.panelControls.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.SuspendLayout();
            // 
            // formsPlotWaveform
            // 
            this.formsPlotWaveform.DisplayScale = 0F;
            this.formsPlotWaveform.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formsPlotWaveform.Location = new System.Drawing.Point(0, 0);
            this.formsPlotWaveform.Margin = new System.Windows.Forms.Padding(4);
            this.formsPlotWaveform.Name = "formsPlotWaveform";
            this.formsPlotWaveform.Size = new System.Drawing.Size(1200, 388);
            this.formsPlotWaveform.TabIndex = 0;
            // 
            // formsPlotLeftSpectrum
            // 
            this.formsPlotLeftSpectrum.DisplayScale = 0F;
            this.formsPlotLeftSpectrum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formsPlotLeftSpectrum.Location = new System.Drawing.Point(0, 0);
            this.formsPlotLeftSpectrum.Margin = new System.Windows.Forms.Padding(4);
            this.formsPlotLeftSpectrum.Name = "formsPlotLeftSpectrum";
            this.formsPlotLeftSpectrum.Size = new System.Drawing.Size(400, 382);
            this.formsPlotLeftSpectrum.TabIndex = 0;
            // 
            // formsPlotRightSpectrum
            // 
            this.formsPlotRightSpectrum.DisplayScale = 0F;
            this.formsPlotRightSpectrum.Dock = System.Windows.Forms.DockStyle.Fill;
            this.formsPlotRightSpectrum.Location = new System.Drawing.Point(0, 0);
            this.formsPlotRightSpectrum.Margin = new System.Windows.Forms.Padding(4);
            this.formsPlotRightSpectrum.Name = "formsPlotRightSpectrum";
            this.formsPlotRightSpectrum.Size = new System.Drawing.Size(794, 382);
            this.formsPlotRightSpectrum.TabIndex = 1;
            // 
            // panelControls
            // 
            this.panelControls.Controls.Add(this.lblFilterStatus);
            this.panelControls.Controls.Add(this.chkFilter);
            this.panelControls.Controls.Add(this.btnPause);
            this.panelControls.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelControls.Location = new System.Drawing.Point(0, 0);
            this.panelControls.Margin = new System.Windows.Forms.Padding(4);
            this.panelControls.Name = "panelControls";
            this.panelControls.Size = new System.Drawing.Size(1200, 55);
            this.panelControls.TabIndex = 1;
            // 
            // lblFilterStatus
            // 
            this.lblFilterStatus.AutoSize = true;
            this.lblFilterStatus.Location = new System.Drawing.Point(315, 17);
            this.lblFilterStatus.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFilterStatus.Name = "lblFilterStatus";
            this.lblFilterStatus.Size = new System.Drawing.Size(170, 18);
            this.lblFilterStatus.TabIndex = 2;
            this.lblFilterStatus.Text = "Filter initialized";
            // 
            // chkFilter
            // 
            this.chkFilter.AutoSize = true;
            this.chkFilter.Location = new System.Drawing.Point(150, 14);
            this.chkFilter.Margin = new System.Windows.Forms.Padding(4);
            this.chkFilter.Name = "chkFilter";
            this.chkFilter.Size = new System.Drawing.Size(151, 22);
            this.chkFilter.TabIndex = 1;
            this.chkFilter.Text = "Enable Filter";
            this.chkFilter.UseVisualStyleBackColor = true;
            this.chkFilter.CheckedChanged += new System.EventHandler(this.ChkFilter_CheckedChanged);
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(18, 11);
            this.btnPause.Margin = new System.Windows.Forms.Padding(4);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(120, 33);
            this.btnPause.TabIndex = 0;
            this.btnPause.Text = "Pause Refresh";
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.BtnPause_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 55);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.formsPlotWaveform);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1200, 776);
            this.splitContainer1.SplitterDistance = 388;
            this.splitContainer1.SplitterWidth = 6;
            this.splitContainer1.TabIndex = 2;
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer2.Name = "splitContainer2";
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.formsPlotLeftSpectrum);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.formsPlotRightSpectrum);
            this.splitContainer2.Size = new System.Drawing.Size(1200, 382);
            this.splitContainer2.SplitterDistance = 400;
            this.splitContainer2.SplitterWidth = 6;
            this.splitContainer2.TabIndex = 1;
            // 
            // EegWaveformForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 831);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.panelControls);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "EegWaveformForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EEG Waveform Display";
            this.panelControls.ResumeLayout(false);
            this.panelControls.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        private ScottPlot.WinForms.FormsPlot formsPlotWaveform;
        private ScottPlot.WinForms.FormsPlot formsPlotLeftSpectrum;
        private ScottPlot.WinForms.FormsPlot formsPlotRightSpectrum;
        private System.Windows.Forms.Panel panelControls;
        private System.Windows.Forms.CheckBox chkFilter;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Label lblFilterStatus;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;

        private void SetupPlots()
        {
            // Set up waveform plot
            formsPlotWaveform.Plot.Title("EEG Waveform - Real-time Display");
            formsPlotWaveform.Plot.XLabel("Time (2ms)");
            formsPlotWaveform.Plot.YLabel("Amplitude (uV)");
            formsPlotWaveform.Plot.Legend.IsVisible = true;
            formsPlotWaveform.Plot.Axes.SetLimitsY(-50, 50);
            formsPlotWaveform.Plot.Axes.SetLimitsX(0, _displayPoints);

            double[] xs = Generate.Consecutive(_displayPoints);
            double[] leftYs = new double[_displayPoints];
            double[] rightYs = new double[_displayPoints];

            var leftSignal = formsPlotWaveform.Plot.Add.SignalXY(xs, leftYs);
            leftSignal.Color = Colors.Blue;
            leftSignal.LineWidth = 1;
            leftSignal.LegendText = "Left Ear";

            var rightSignal = formsPlotWaveform.Plot.Add.SignalXY(xs, rightYs);
            rightSignal.Color = Colors.Red;
            rightSignal.LineWidth = 1;
            rightSignal.LegendText = "Right Ear";

            // Set up left ear energy spectrum plot
            formsPlotLeftSpectrum.Plot.Title("Left Ear Energy Spectrum");
            formsPlotLeftSpectrum.Plot.XLabel("Time (s)");
            formsPlotLeftSpectrum.Plot.YLabel("Energy Ratio");
            formsPlotLeftSpectrum.Plot.Legend.IsVisible = true;
            formsPlotLeftSpectrum.Plot.Axes.SetLimitsY(0, 1);
            formsPlotLeftSpectrum.Plot.Axes.SetLimitsX(0, SPECTRUM_HISTORY_SECONDS);

            // Set up right ear energy spectrum plot
            formsPlotRightSpectrum.Plot.Title("Right Ear Energy Spectrum");
            formsPlotRightSpectrum.Plot.XLabel("Time (s)");
            formsPlotRightSpectrum.Plot.YLabel("Energy Ratio");
            formsPlotRightSpectrum.Plot.Legend.IsVisible = true;
            formsPlotRightSpectrum.Plot.Axes.SetLimitsY(0, 1);
            formsPlotRightSpectrum.Plot.Axes.SetLimitsX(0, SPECTRUM_HISTORY_SECONDS);

            formsPlotWaveform.Refresh();
            formsPlotLeftSpectrum.Refresh();
            formsPlotRightSpectrum.Refresh();
        }

        private void UpdateFilterControls()
        {
            if (_sdkApi.IsInitialized)
            {
                lblFilterStatus.Text = "Filter initialized";
                lblFilterStatus.ForeColor = System.Drawing.Color.Green;
                chkFilter.Enabled = true;
            }
            else
            {
                lblFilterStatus.Text = "Filter not initialized";
                lblFilterStatus.ForeColor = System.Drawing.Color.Red;
                chkFilter.Enabled = false;
                chkFilter.Checked = false;
            }
        }

        private void BtnPause_Click(object sender, EventArgs e)
        {
            _isPaused = !_isPaused;
            if (_isPaused)
            {
                btnPause.Text = "Resume Refresh";
                _refreshTimer.Stop();
            }
            else
            {
                btnPause.Text = "Pause Refresh";
                _refreshTimer.Start();
            }
        }

        private void ChkFilter_CheckedChanged(object sender, EventArgs e)
        {
            _useFilteredData = chkFilter.Checked;
        }

        private void RefreshTimer_Tick(object sender, EventArgs e)
        {
            UpdateWaveform();
        }

        private void UpdateWaveform()
        {
            float[] leftData = _sdkApi.GetLatestEegData(EarSide.Left, _displaySeconds, _useFilteredData);
            float[] rightData = _sdkApi.GetLatestEegData(EarSide.Right, _displaySeconds, _useFilteredData);

            double[] leftYs = new double[_displayPoints];
            double[] rightYs = new double[_displayPoints];

            if (leftData != null && leftData.Length > 0)
            {
                int copyLength = Math.Min(leftData.Length, _displayPoints);
                int startIndex = _displayPoints - copyLength;

                for (int i = 0; i < copyLength; i++)
                {
                    leftYs[startIndex + i] = leftData[leftData.Length - copyLength + i];
                }
            }

            if (rightData != null && rightData.Length > 0)
            {
                int copyLength = Math.Min(rightData.Length, _displayPoints);
                int startIndex = _displayPoints - copyLength;

                for (int i = 0; i < copyLength; i++)
                {
                    rightYs[startIndex + i] = rightData[rightData.Length - copyLength + i];
                }
            }

            formsPlotWaveform.Plot.Clear();

            double[] xs = Generate.Consecutive(_displayPoints);

            var leftSignal = formsPlotWaveform.Plot.Add.SignalXY(xs, leftYs);
            leftSignal.Color = Colors.Blue;
            leftSignal.LineWidth = 1;
            leftSignal.LegendText = "Left Ear";

            var rightSignal = formsPlotWaveform.Plot.Add.SignalXY(xs, rightYs);
            rightSignal.Color = Colors.Red;
            rightSignal.LineWidth = 1;
            rightSignal.LegendText = "Right Ear";

            formsPlotWaveform.Refresh();
        }

        private void SdkApi_SpectrumDataReceived(object sender, SpectrumDataEventArgs e)
        {
            // Extract energy values for each frequency band
            double leftTheta = e.LeftTheta[0];
            double leftAlpha = e.LeftAlpha[0];
            double leftBeta = e.LeftBeta[0];
            double leftGamma = e.LeftGamma[0];

            double rightTheta = e.RightTheta[0];
            double rightAlpha = e.RightAlpha[0];
            double rightBeta = e.RightBeta[0];
            double rightGamma = e.RightGamma[0];

            // Calculate total energy
            double leftTotal = leftTheta + leftAlpha + leftBeta + leftGamma;
            double rightTotal = rightTheta + rightAlpha + rightBeta + rightGamma;

            // Calculate percentage for each frequency band
            double[] leftPercentages = new double[4];
            if (leftTotal > 0)
            {
                leftPercentages[0] = leftTheta / leftTotal;   // theta
                leftPercentages[1] = leftAlpha / leftTotal;   // alpha
                leftPercentages[2] = leftBeta / leftTotal;    // beta
                leftPercentages[3] = leftGamma / leftTotal;   // gamma
            }

            double[] rightPercentages = new double[4];
            if (rightTotal > 0)
            {
                rightPercentages[0] = rightTheta / rightTotal;   // theta
                rightPercentages[1] = rightAlpha / rightTotal;   // alpha
                rightPercentages[2] = rightBeta / rightTotal;    // beta
                rightPercentages[3] = rightGamma / rightTotal;   // gamma
            }

            // Add to history data (circular replacement)
            _leftSpectrumData[_currentIndex] = leftPercentages;
            _rightSpectrumData[_currentIndex] = rightPercentages;

            // Update current index
            _currentIndex = (_currentIndex + 1) % SPECTRUM_HISTORY_SECONDS;

            // If paused, don't update spectrum data
            if (_isPaused)
                return;
                
            // Use Invoke to ensure UI updates are executed on the main thread
            if (InvokeRequired)
            {
                Invoke(new Action(UpdateSpectrumPlots));
            }
            else
            {
                UpdateSpectrumPlots();
            }
        }

        private void UpdateSpectrumPlots()
        {
            // Update left ear energy spectrum
            formsPlotLeftSpectrum.Plot.Clear();
            formsPlotLeftSpectrum.Plot.Title("Left Ear Energy Spectrum");
            formsPlotLeftSpectrum.Plot.XLabel("Time (s)");
            formsPlotLeftSpectrum.Plot.YLabel("Energy Ratio");
            formsPlotLeftSpectrum.Plot.Legend.IsVisible = true;
            formsPlotLeftSpectrum.Plot.Axes.SetLimitsY(0, 1);
            formsPlotLeftSpectrum.Plot.Axes.SetLimitsX(0, SPECTRUM_HISTORY_SECONDS);

            // Check if there is data
            bool hasData = false;
            for (int i = 0; i < SPECTRUM_HISTORY_SECONDS; i++)
            {
                if (_leftSpectrumData[i] != null)
                {
                    hasData = true;
                    break;
                }
            }

            if (hasData)
            {
                double[] xs = new double[SPECTRUM_HISTORY_SECONDS];
                double[] thetaYs = new double[SPECTRUM_HISTORY_SECONDS];
                double[] alphaYs = new double[SPECTRUM_HISTORY_SECONDS];
                double[] betaYs = new double[SPECTRUM_HISTORY_SECONDS];
                double[] gammaYs = new double[SPECTRUM_HISTORY_SECONDS];

                // Display data in array index order (0 to 59)
                for (int i = 0; i < SPECTRUM_HISTORY_SECONDS; i++)
                {
                    xs[i] = i;
                    
                    if (_leftSpectrumData[i] != null)
                    {
                        thetaYs[i] = _leftSpectrumData[i][0];   // theta
                        alphaYs[i] = thetaYs[i] + _leftSpectrumData[i][1];   // theta + alpha
                        betaYs[i] = alphaYs[i] + _leftSpectrumData[i][2];    // theta + alpha + beta
                        gammaYs[i] = betaYs[i] + _leftSpectrumData[i][3];   // theta + alpha + beta + gamma
                    }
                    else
                    {
                        thetaYs[i] = 0;
                        alphaYs[i] = 0;
                        betaYs[i] = 0;
                        gammaYs[i] = 0;
                    }
                }

                // Get latest spectrum data (previous position of current index)
                int latestIndex = (_currentIndex - 1 + SPECTRUM_HISTORY_SECONDS) % SPECTRUM_HISTORY_SECONDS;
                double[] latestLeftData = _leftSpectrumData[latestIndex] ?? new double[4];
                double leftTheta = latestLeftData[0];
                double leftAlpha = latestLeftData[1];
                double leftBeta = latestLeftData[2];
                double leftGamma = latestLeftData[3];

                // Plot lines for each frequency band with different colors
                var gammaSignal = formsPlotLeftSpectrum.Plot.Add.SignalXY(xs, gammaYs);
                gammaSignal.Color = Colors.Red;
                gammaSignal.LineWidth = 2;
                gammaSignal.LegendText = string.Format("Gamma:  {0:F2}", leftGamma);

                var betaSignal = formsPlotLeftSpectrum.Plot.Add.SignalXY(xs, betaYs);
                betaSignal.Color = Colors.Yellow;
                betaSignal.LineWidth = 2;
                betaSignal.LegendText = string.Format("Beta:   {0:F2}", leftBeta);

                var alphaSignal = formsPlotLeftSpectrum.Plot.Add.SignalXY(xs, alphaYs);
                alphaSignal.Color = Colors.Green;
                alphaSignal.LineWidth = 2;
                alphaSignal.LegendText = string.Format("Alpha:  {0:F2}", leftAlpha);

                var thetaSignal = formsPlotLeftSpectrum.Plot.Add.SignalXY(xs, thetaYs);
                thetaSignal.Color = Colors.Blue;
                thetaSignal.LineWidth = 2;
                thetaSignal.LegendText = string.Format("Theta:  {0:F2}", leftTheta);
                
                // Add vertical line indicator at current data position (latestIndex, i.e., latest data position)
                double currentX = latestIndex;
                var vline = formsPlotLeftSpectrum.Plot.Add.VerticalLine(currentX);
                vline.Color = Colors.Black;
                vline.LineWidth = 1;
            }

            // Update right ear energy spectrum
            formsPlotRightSpectrum.Plot.Clear();
            formsPlotRightSpectrum.Plot.Title("Right Ear Energy Spectrum");
            formsPlotRightSpectrum.Plot.XLabel("Time (s)");
            formsPlotRightSpectrum.Plot.YLabel("Energy Ratio");
            formsPlotRightSpectrum.Plot.Legend.IsVisible = true;
            formsPlotRightSpectrum.Plot.Axes.SetLimitsY(0, 1);
            formsPlotRightSpectrum.Plot.Axes.SetLimitsX(0, SPECTRUM_HISTORY_SECONDS);

            // Check if there is data
            hasData = false;
            for (int i = 0; i < SPECTRUM_HISTORY_SECONDS; i++)
            {
                if (_rightSpectrumData[i] != null)
                {
                    hasData = true;
                    break;
                }
            }

            if (hasData)
            {
                double[] xs = new double[SPECTRUM_HISTORY_SECONDS];
                double[] thetaYs = new double[SPECTRUM_HISTORY_SECONDS];
                double[] alphaYs = new double[SPECTRUM_HISTORY_SECONDS];
                double[] betaYs = new double[SPECTRUM_HISTORY_SECONDS];
                double[] gammaYs = new double[SPECTRUM_HISTORY_SECONDS];

                // Display data in array index order (0 to 59)
                for (int i = 0; i < SPECTRUM_HISTORY_SECONDS; i++)
                {
                    xs[i] = i;
                    
                    if (_rightSpectrumData[i] != null)
                    {
                        thetaYs[i] = _rightSpectrumData[i][0];   // theta
                        alphaYs[i] = thetaYs[i] + _rightSpectrumData[i][1];   // theta + alpha
                        betaYs[i] = alphaYs[i] + _rightSpectrumData[i][2];    // theta + alpha + beta
                        gammaYs[i] = betaYs[i] + _rightSpectrumData[i][3];   // theta + alpha + beta + gamma
                    }
                    else
                    {
                        thetaYs[i] = 0;
                        alphaYs[i] = 0;
                        betaYs[i] = 0;
                        gammaYs[i] = 0;
                    }
                }

                // Get latest spectrum data (previous position of current index)
                int latestIndex = (_currentIndex - 1 + SPECTRUM_HISTORY_SECONDS) % SPECTRUM_HISTORY_SECONDS;
                double[] latestRightData = _rightSpectrumData[latestIndex] ?? new double[4];
                double rightTheta = latestRightData[0];
                double rightAlpha = latestRightData[1];
                double rightBeta = latestRightData[2];
                double rightGamma = latestRightData[3];

                // Plot lines for each frequency band with different colors
                var gammaSignal = formsPlotRightSpectrum.Plot.Add.SignalXY(xs, gammaYs);
                gammaSignal.Color = Colors.Red;
                gammaSignal.LineWidth = 2;
                gammaSignal.LegendText = string.Format("Gamma:  {0:F2}", rightGamma);

                var betaSignal = formsPlotRightSpectrum.Plot.Add.SignalXY(xs, betaYs);
                betaSignal.Color = Colors.Yellow;
                betaSignal.LineWidth = 2;
                betaSignal.LegendText = string.Format("Beta:   {0:F2}", rightBeta);

                var alphaSignal = formsPlotRightSpectrum.Plot.Add.SignalXY(xs, alphaYs);
                alphaSignal.Color = Colors.Green;
                alphaSignal.LineWidth = 2;
                alphaSignal.LegendText = string.Format("Alpha:  {0:F2}", rightAlpha);

                var thetaSignal = formsPlotRightSpectrum.Plot.Add.SignalXY(xs, thetaYs);
                thetaSignal.Color = Colors.Blue;
                thetaSignal.LineWidth = 2;
                thetaSignal.LegendText = string.Format("Theta:  {0:F2}", rightTheta);
                
                // Add vertical line indicator at current data position (latestIndex, i.e., latest data position)
                double currentX = latestIndex;
                var vline = formsPlotRightSpectrum.Plot.Add.VerticalLine(currentX);
                vline.Color = Colors.Black;
                vline.LineWidth = 1;
            }

            formsPlotLeftSpectrum.Refresh();
            formsPlotRightSpectrum.Refresh();
        }

        public void StartDisplay()
        {
            _refreshTimer.Start();
        }

        public void StopDisplay()
        {
            _refreshTimer.Stop();
        }

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            _refreshTimer.Stop();
            _refreshTimer.Dispose();
            // Unsubscribe from events
            _sdkApi.SpectrumDataReceived -= SdkApi_SpectrumDataReceived;
            base.OnFormClosing(e);
        }
    }
}
