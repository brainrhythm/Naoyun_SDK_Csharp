using System;
using System.Windows.Forms;
using NaoyunSdkSample.Services;

namespace NaoyunSdkSample
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            // Initialize SDK service
            try
            {
                var sdkService = SdkService.Instance;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"SDK initialization failed: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            
            Application.Run(new MainForm());
        }
    }
}
