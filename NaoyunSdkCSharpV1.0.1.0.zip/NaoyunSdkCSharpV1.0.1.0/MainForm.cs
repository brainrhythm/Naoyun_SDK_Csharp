using NaoyunSdk.Interfaces;
using NaoyunSdk.Net;
using NaoyunSdkSample.Services;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace NaoyunSdkSample
{
    /// <summary>
    /// Main form of the Naoyun SDK Sample application
    /// </summary>
    public partial class MainForm : Form
    {
        /// <summary>
        /// SDK API instance
        /// </summary>
        private INaoyunSdkApi _sdkApi;
        /// <summary>
        /// Currently selected BLE device
        /// </summary>
        private BleDeviceInfo _selectedDevice;
        /// <summary>
        /// Timer for scanning devices
        /// </summary>
        private Timer _scanTimer;
        /// <summary>
        /// Remaining scanning time in seconds
        /// </summary>
        private int _scanRemainingSeconds;

        /// <summary>
        /// Recording related variables
        /// </summary>
        private bool _isRecording;
        private DateTime _recordingStartTime;
        private System.Windows.Forms.Timer _recordingTimer;
        /// <summary>
        /// Left ear EEG data
        /// </summary>
        private List<float[]> _leftEarData;
        /// <summary>
        /// Right ear EEG data
        /// </summary>
        private List<float[]> _rightEarData;
        /// <summary>
        /// Left ear timestamps
        /// </summary>
        private List<DateTime> _leftTimestamps;
        /// <summary>
        /// Right ear timestamps
        /// </summary>
        private List<DateTime> _rightTimestamps;

        /// <summary>
        /// Original form size
        /// </summary>
        private Size _originalSize;
        /// <summary>
        /// Original control locations and sizes
        /// </summary>
        private Dictionary<Control, (Point Location, Size Size)> _originalControlInfo;

        /// <summary>
        /// Buttons
        /// </summary>
        private System.Windows.Forms.Button btnStartData;
        private System.Windows.Forms.Button btnStopData;

        /// <summary>
        /// Constructor
        /// </summary>
        public MainForm()
        {
            InitializeComponent();
            InitializeComponents();
        }

        /// <summary>
        /// Initialize components and event handlers
        /// </summary>
        private void InitializeComponents()
        {
            _sdkApi = SdkService.Instance.SdkApi;
            _scanTimer = new Timer();
            _scanTimer.Interval = 1000;
            _scanTimer.Tick += ScanTimer_Tick;

            // Initialize recording related variables
            _isRecording = false;
            _recordingTimer = new System.Windows.Forms.Timer();
            _recordingTimer.Interval = 1000;
            _recordingTimer.Tick += RecordingTimer_Tick;
            _leftEarData = new List<float[]>();
            _rightEarData = new List<float[]>();
            _leftTimestamps = new List<DateTime>();
            _rightTimestamps = new List<DateTime>();

            // Subscribe to SDK events
            _sdkApi.ConnectionStateChanged += SdkApi_ConnectionStateChanged;
            _sdkApi.DataReceived += SdkApi_DataReceived;
            _sdkApi.DeviceStatusNotificationReceived += SdkApi_DeviceStatusNotificationReceived;

            _sdkApi.BleDeviceDiscovered += SdkApi_BleDeviceDiscovered;
            _sdkApi.SpectrumDataReceived += SdkApi_SpectrumDataReceived;
            _sdkApi.SpectrumTaskStatusChanged += SdkApi_SpectrumTaskStatusChanged;
            _sdkApi.ServerAuthCompleted += SdkApi_ServerAuthCompleted;
            _sdkApi.MentalStateDataReceived += SdkApi_MentalStateDataReceived;

            // Ensure buttons are displayed at the front
            this.Load += (sender, e) =>
            {
                btnStartRecording.BringToFront();
                btnStopRecording.BringToFront();
                btnStartData.BringToFront();
                btnStopData.BringToFront();
            };
        }

        /// <summary>
        /// Handle scan timer tick event
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="e">Event arguments</param>
        private void ScanTimer_Tick(object sender, EventArgs e)
        {
            _scanRemainingSeconds--;
            if (_scanRemainingSeconds >= 0)
            {
                btnScan.Text = string.Format("Scan Devices ({0}s)", _scanRemainingSeconds);
            }
        }

        private void RecordingTimer_Tick(object sender, EventArgs e)
        {
            TimeSpan elapsed = DateTime.Now - _recordingStartTime;
            lblRecordingDuration.Text = elapsed.ToString(@"hh\:mm\:ss");
        }

        /// <summary>
        /// Handle form load event
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="e">Event arguments</param>
        private void MainForm_Load(object sender, EventArgs e)
        {
            // Save original size and control positions
            _originalSize = this.Size;
            _originalControlInfo = new Dictionary<Control, (Point Location, Size Size)>();
            SaveControlInfo(this.Controls);

            // Subscribe to resize event
            this.Resize += MainForm_Resize;

            // Add SDK version to form title
            this.Text = $"Naoyun SDK Sample - v{_sdkApi.GetSdkVersion()}";

            UpdateUI();
        }

        /// <summary>
        /// Save control locations and sizes
        /// </summary>
        /// <param name="controls">Control collection</param>
        private void SaveControlInfo(Control.ControlCollection controls)
        {
            foreach (Control control in controls)
            {
                // Skip menuStrip and statusStrip as they are special
                if (control is MenuStrip || control is StatusStrip)
                    continue;

                _originalControlInfo[control] = (control.Location, control.Size);

                // Recursively save child controls
                if (control.HasChildren)
                {
                    SaveControlInfo(control.Controls);
                }
            }
        }

        /// <summary>
        /// Handle form resize event
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="e">Event arguments</param>
        private void MainForm_Resize(object sender, EventArgs e)
        {
            // Calculate scaling factors
            float scaleX = (float)this.Width / _originalSize.Width;
            float scaleY = (float)this.Height / _originalSize.Height;

            // Scale controls
            ScaleControls(this.Controls, scaleX, scaleY);
        }

        /// <summary>
        /// Scale controls recursively
        /// </summary>
        /// <param name="controls">Control collection</param>
        /// <param name="scaleX">Horizontal scaling factor</param>
        /// <param name="scaleY">Vertical scaling factor</param>
        private void ScaleControls(Control.ControlCollection controls, float scaleX, float scaleY)
        {
            foreach (Control control in controls)
            {
                // Skip menuStrip and statusStrip as they are special
                if (control is MenuStrip || control is StatusStrip)
                    continue;

                if (_originalControlInfo.ContainsKey(control))
                {
                    var (originalLocation, originalSize) = _originalControlInfo[control];

                    // Calculate new location and size
                    int newX = (int)(originalLocation.X * scaleX);
                    int newY = (int)(originalLocation.Y * scaleY);
                    int newWidth = (int)(originalSize.Width * scaleX);
                    int newHeight = (int)(originalSize.Height * scaleY);

                    // Apply new location and size
                    control.Location = new Point(newX, newY);
                    control.Size = new Size(newWidth, newHeight);
                }

                // Recursively scale child controls
                if (control.HasChildren)
                {
                    ScaleControls(control.Controls, scaleX, scaleY);
                }
            }
        }

        /// <summary>
        /// Log a message to the log window
        /// </summary>
        /// <param name="message">Message to log</param>
        private void Log(string message)
        {
            if (IsDisposed || Disposing)
                return;

            if (InvokeRequired)
            {
                try
                {
                    Invoke(new Action(() => Log(message)));
                }
                catch (ObjectDisposedException)
                {
                }
                return;
            }
            txtLog.AppendText(string.Format("[{0:HH:mm:ss}] {1}{2}", DateTime.Now, message, Environment.NewLine));
            WriteLogToFile(message);
        }

        private void WriteLogToFile(string message)
        {
            try
            {
                string logDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "log");
                string datePath = Path.Combine(DateTime.Now.Year.ToString(), DateTime.Now.Month.ToString("D2"));
                logDir = Path.Combine(logDir, datePath);
                Directory.CreateDirectory(logDir);
                string filePath = Path.Combine(logDir, DateTime.Now.ToString("yyyyMMdd") + ".txt");
                string logLine = string.Format("[{0:HH:mm:ss}] {1}", DateTime.Now, message);
                File.AppendAllText(filePath, logLine + Environment.NewLine);
            }
            catch
            {
            }
        }

        /// <summary>
        /// Update UI elements based on current state
        /// </summary>
        private void UpdateUI()
        {
            btnScan.Visible = true;
            grpDevice.Visible = true;
            grpDevice.Text = "Device List";

            lstDevices.Items.Clear();
            btnConnect.Enabled = lstDevices.SelectedItem != null;
        }

        /// <summary>
        /// Handle scan button click event
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="e">Event arguments</param>
        private async void BtnScan_Click(object sender, EventArgs e)
        {
            if (btnDisconnect.Enabled)
            {
                DialogResult result = MessageBox.Show("Device is already connected. Do you want to disconnect first?", "Connection Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (result != DialogResult.Yes)
                    return;
                
                BtnDisconnect_Click(sender, e);
                return;
            }
            
            btnScan.Enabled = false;
            btnStopScan.Enabled = true;
            lstDevices.Items.Clear();
            Log("Starting BLE device scan...");

            // Check Bluetooth status
            CheckBluetoothStatus();

            _scanRemainingSeconds = 10;
            btnScan.Text = string.Format("Scan Devices ({0}s)", _scanRemainingSeconds);
            _scanTimer.Start();

            try
            {
                await _sdkApi.StartBleScanAsync(TimeSpan.FromSeconds(_scanRemainingSeconds));
                Log("Scan completed");
            }
            catch (Exception ex)
            {
                Log(string.Format("Scan failed: {0}", ex.Message));
                Log(string.Format("Details: {0}", ex.StackTrace));
            }
            finally
            {
                _scanTimer.Stop();
                btnScan.Text = "Scan Devices";
                btnScan.Enabled = true;
                btnStopScan.Enabled = false;
            }
        }

        private void BtnStopScan_Click(object sender, EventArgs e)
        {
            _scanTimer.Stop();
            _sdkApi.StopBleScanAsync();
            btnScan.Text = "Scan Devices";
            btnScan.Enabled = true;
            btnStopScan.Enabled = false;
            Log("Scan stopped");
        }

        /// <summary>
        /// Check Bluetooth status and API availability
        /// </summary>
        private void CheckBluetoothStatus()
        {
            try
            {
                // Check if Bluetooth API is available
                var watcherType = Type.GetType("Windows.Devices.Bluetooth.Advertisement.BluetoothLEAdvertisementWatcher, Windows, Version=255.255.255.255, Culture=neutral, PublicKeyToken=null, ContentType=WindowsRuntime");
                if (watcherType == null)
                {
                    watcherType = Type.GetType("Windows.Devices.Bluetooth.Advertisement.BluetoothLEAdvertisementWatcher");
                }

                if (watcherType != null)
                {
                    Log("Bluetooth API available");
                }
                else
                {
                    Log("Bluetooth API not available, using mock mode");
                }
            }
            catch (Exception ex)
            {
                Log(string.Format("Bluetooth status check failed: {0}", ex.Message));
            }
        }

        /// <summary>
        /// Handle BLE device discovered event
        /// </summary>
        /// <param name="sender">Event sender</param>
        /// <param name="device">Discovered device info</param>
        private void SdkApi_BleDeviceDiscovered(object sender, BleDeviceInfo device)
        {
            if (IsDisposed || Disposing)
                return;

            if (InvokeRequired)
            {
                try
                {
                    Invoke(new Action(() => SdkApi_BleDeviceDiscovered(sender, device)));
                }
                catch (ObjectDisposedException)
                {
                }
                return;
            }

            lstDevices.Items.Add(device);
            Log(string.Format("Device discovered: {0} ({1})", device.Name, device.Id));
        }

        private void LstDevices_SelectedIndexChanged(object sender, EventArgs e)
        {
            _selectedDevice = lstDevices.SelectedItem as BleDeviceInfo;
            btnConnect.Enabled = lstDevices.SelectedItem != null;
        }

        private async void BtnConnect_Click(object sender, EventArgs e)
        {
            await ConnectBleAsync();
        }

        private async System.Threading.Tasks.Task ConnectBleAsync()
        {
            if (_selectedDevice == null)
                return;

            // Stop scanning if in progress
            if (btnStopScan.Enabled)
            {
                BtnStopScan_Click(this, EventArgs.Empty);
                Log("Stopped ongoing scan before connecting");
            }

            btnConnect.Enabled = false;
            btnScan.Enabled = false;
            Log(string.Format("Connecting to BLE device: {0}...", _selectedDevice.Name));

            try
            {
                bool success = await _sdkApi.ConnectBleAsync(_selectedDevice.BluetoothAddress);
                if (!success)
                {
                    Log("Connection failed");
                    btnConnect.Enabled = true;
                    btnScan.Enabled = true;
                }
            }
            catch (Exception ex)
            {
                Log(string.Format("Connection failed: {0}", ex.ToString()));
                btnConnect.Enabled = true;
                btnScan.Enabled = true;
            }
        }

        private void SdkApi_ConnectionStateChanged(object sender, DeviceStateEventArgs e)
        {
            if (IsDisposed || Disposing)
                return;

            if (InvokeRequired)
            {
                try
                {
                    Invoke(new Action(() => SdkApi_ConnectionStateChanged(sender, e)));
                }
                catch (ObjectDisposedException)
                {
                }
                return;
            }

            if (e.IsConnected)
            {
                lblStatus.Text = string.Format("Status: Connected - {0}", e.Message);
                btnDisconnect.Enabled = true;
                btnStartData.Enabled = true;
                btnStopData.Enabled = true;
                btnStartRecording.Enabled = true;
                btnStopRecording.Enabled = true;
                btnNoiseReductionOff.Enabled = true;
                btnNoiseReductionOn.Enabled = true;
                btnEnvironmentalSound.Enabled = true;
                btnTouchOn.Enabled = true;
                btnTouchOff.Enabled = true;
                btnAutoPlayOn.Enabled = true;
                btnAutoPlayOff.Enabled = true;
                lstDevices.Items.Clear();
            }
            else
            {
                if (_isRecording)
                {
                    _isRecording = false;
                    _recordingTimer.Stop();

                    SaveDataToCsv();
                    Log("Bluetooth disconnected during recording, auto-stopped and saved");
                }
                OnDisconnected();
            }
            Log(e.Message ?? (e.IsConnected ? "Connected" : "Disconnected"));
        }

        private void SdkApi_DataReceived(object sender, DataReceivedEventArgs e)
        {
            if (IsDisposed || Disposing)
                return;

            if (InvokeRequired)
            {
                try
                {
                    Invoke(new Action(() => SdkApi_DataReceived(sender, e)));
                }
                catch (ObjectDisposedException)
                {
                }
                return;
            }

            if (!e.IsValid)
            {
                Log(string.Format("Data parsing failed: {0}", e.ErrorMessage));
                return;
            }

            // Record data
            if (_isRecording)
            {
                if (e.EarSide == EarSide.Left)
                {
                    _leftEarData.Add(e.Data);
                    _leftTimestamps.Add(DateTime.Now);
                }
                else if (e.EarSide == EarSide.Right)
                {
                    _rightEarData.Add(e.Data);
                    _rightTimestamps.Add(DateTime.Now);
                }
            }

            string earSide = e.EarSide == EarSide.Left ? "Left Ear" : "Right Ear";
            StringBuilder sb = new StringBuilder();
            sb.AppendLine(string.Format("Data - {0}, Packet Counter: {1}", earSide, e.PacketCounter));
            sb.Append("Data: ");
            for (int i = 0; i < e.Data.Length && i < 10; i++)
            {
                sb.Append(string.Format("{0:F2} ", e.Data[i]));
            }
            if (e.Data.Length > 10)
            {
                sb.Append(string.Format("... (Total: {0} sets)", e.Data.Length));
            }
            //Log(sb.ToString());
        }

        private void SdkApi_DeviceStatusNotificationReceived(object sender, DeviceStatusNotificationEventArgs e)
        {
            if (IsDisposed || Disposing)
                return;

            if (InvokeRequired)
            {
                try
                {
                    Invoke(new Action(() => SdkApi_DeviceStatusNotificationReceived(sender, e)));
                }
                catch (ObjectDisposedException)
                {
                }
                return;
            }

            // When battery level is 0xff, display "-"
            string leftBatteryText = e.LeftBattery == 0xff ? "-" : e.LeftBattery.ToString();
            string rightBatteryText = e.RightBattery == 0xff ? "-" : e.RightBattery.ToString();
            tsslLeftBattery.Text = string.Format("L Batt: {0}%", leftBatteryText);
            tsslRightBattery.Text = string.Format("R Batt: {0}%", rightBatteryText);
            tsslLeftWorn.Text = string.Format("L Worn: {0}", e.LeftWorn ? "Yes" : "No");
            tsslRightWorn.Text = string.Format("R Worn: {0}", e.RightWorn ? "Yes" : "No");
            tsslVersion.Text = string.Format("Ver: {0}", e.SoftwareVersion);

            string noiseMode;
            switch (e.NoiseReductionMode)
            {
                case 0:
                    noiseMode = "Off";
                    break;
                case 1:
                    noiseMode = "Noise Reduction";
                    break;
                case 2:
                    noiseMode = "Environmental Sound";
                    break;
                default:
                    noiseMode = "Unknown";
                    break;
            }
            tsslNoiseReduction.Text = string.Format("NR: {0}", noiseMode);

            // Update connected side
            string earSide;
            switch (e.EarSide)
            {
                case 1:
                    earSide = "Left Ear";
                    break;
                case 2:
                    earSide = "Right Ear";
                    break;
                case 3:
                    earSide = "Both Ears (Left)";
                    break;
                case 4:
                    earSide = "Both Ears (Right)";
                    break;
                default:
                    earSide = "Unknown";
                    break;
            }
            tsslEarSide.Text = string.Format("Conn: {0}", earSide);

            // Update touch switch status
            tsslTouch.Text = string.Format("Touch: {0}", e.TouchEnabled ? "On" : "Off");

            // Update auto play switch status
            tsslAutoPlay.Text = string.Format("Auto: {0}", e.AutoPlayStopEnabled ? "On" : "Off");
        }

        private void OnDisconnected()
        {
            lblStatus.Text = "Status: Disconnected";
            btnDisconnect.Enabled = false;
            btnConnect.Enabled = lstDevices.SelectedItem != null;
            btnScan.Enabled = true;
            btnStartData.Enabled = false;
            btnStopData.Enabled = false;
            btnStartRecording.Enabled = false;
            btnStopRecording.Enabled = false;
            btnNoiseReductionOff.Enabled = false;
            btnNoiseReductionOn.Enabled = false;
            btnEnvironmentalSound.Enabled = false;
            btnTouchOn.Enabled = false;
            btnTouchOff.Enabled = false;
            btnAutoPlayOn.Enabled = false;
            btnAutoPlayOff.Enabled = false;
        }





        private async void BtnDisconnect_Click(object sender, EventArgs e)
        {
            Log("Disconnecting...");
            await _sdkApi.DisconnectAsync();
        }

        private async void BtnStartData_Click(object sender, EventArgs e)
        {
            Log("Sending start data command...");
            bool success = await _sdkApi.SendStartDataAsync();
            if (success)
            {
                Log("Start data command sent successfully");
                _sdkApi.StartMentalStateTask(1);

            }
            else
            {
                Log("Failed to send start data command");
            }
        }

        private async void BtnStopData_Click(object sender, EventArgs e)
        {
            Log("Sending stop data command...");
            bool success = await _sdkApi.SendStopDataAsync();
            if (success)
            {
                Log("Stop data command sent successfully");
            }
            else
            {
                Log("Failed to send stop data command");
            }
        }

        private async void BtnStartRecording_Click(object sender, EventArgs e)
        {
            Log("Starting data recording...");

            // Send start data command
            bool success = await _sdkApi.SendStartDataAsync();
            if (success)
            {
                Log("Start data command sent successfully");

                // Initialize recording data lists
                _leftEarData.Clear();
                _rightEarData.Clear();
                _leftTimestamps.Clear();
                _rightTimestamps.Clear();

                // Set recording status to true
                _isRecording = true;
                _recordingStartTime = DateTime.Now;
                lblRecordingDuration.Text = "00:00:00";
                _recordingTimer.Start();

                btnStartRecording.Enabled = false;
                btnStopRecording.Enabled = true;
                _sdkApi.StartMentalStateTask(1);
            }
            else
            {
                Log("Failed to send start data command");
            }
        }

        private async void BtnStopRecording_Click(object sender, EventArgs e)
        {
            Log("Stopping data recording...");

            // Set recording status to false
            _isRecording = false;
            _recordingTimer.Stop();

            // Send stop data command
            bool success = await _sdkApi.SendStopDataAsync();
            if (success)
            {
                Log("Stop data command sent successfully");

                // Save data to CSV file
                SaveDataToCsv();
            }
            else
            {
                Log("Failed to send stop data command");
            }

            btnStartRecording.Enabled = true;
            btnStopRecording.Enabled = false;
        }

        private void SaveDataToCsv()
        {
            try
            {
                string dataDir = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "data");
                string datePath = Path.Combine(DateTime.Now.Year.ToString(), DateTime.Now.Month.ToString("D2"));
                dataDir = Path.Combine(dataDir, datePath);
                Directory.CreateDirectory(dataDir);

                string fileName = string.Format("Naoyun_EEG_Data_{0:yyyyMMdd_HHmmss}.xlsx", DateTime.Now);
                string filePath = Path.Combine(dataDir, fileName);

                using (ExcelPackage package = new ExcelPackage())
                {
                    ExcelWorksheet leftSheet = package.Workbook.Worksheets.Add("Left Ear Data");
                    leftSheet.Cells["A1"].Value = "Timestamp";
                    leftSheet.Cells["B1"].Value = "EEG Data";

                    for (int i = 0; i < _leftEarData.Count; i++)
                    {
                        string timestamp = i < _leftTimestamps.Count ? _leftTimestamps[i].ToString("yyyy-MM-dd HH:mm:ss.fff") : "";
                        string data = string.Join(",", _leftEarData[i]);
                        leftSheet.Cells[i + 2, 1].Value = timestamp;
                        leftSheet.Cells[i + 2, 2].Value = data;
                    }

                    ExcelWorksheet rightSheet = package.Workbook.Worksheets.Add("Right Ear Data");
                    rightSheet.Cells["A1"].Value = "Timestamp";
                    rightSheet.Cells["B1"].Value = "EEG Data";

                    for (int i = 0; i < _rightEarData.Count; i++)
                    {
                        string timestamp = i < _rightTimestamps.Count ? _rightTimestamps[i].ToString("yyyy-MM-dd HH:mm:ss.fff") : "";
                        string data = string.Join(",", _rightEarData[i]);
                        rightSheet.Cells[i + 2, 1].Value = timestamp;
                        rightSheet.Cells[i + 2, 2].Value = data;
                    }

                    leftSheet.Cells[leftSheet.Dimension.Address].AutoFitColumns();
                    rightSheet.Cells[rightSheet.Dimension.Address].AutoFitColumns();

                    FileInfo excelFile = new FileInfo(filePath);
                    package.SaveAs(excelFile);
                }

                Log(string.Format("Data saved to: {0}", filePath));
            }
            catch (Exception ex)
            {
                Log(string.Format("Failed to save data: {0}", ex.Message));
            }
        }

        private void EnsureDirectoryExists(string filePath)
        {
            string directory = Path.GetDirectoryName(filePath);
            if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            _scanTimer.Stop();
            _sdkApi.ConnectionStateChanged -= SdkApi_ConnectionStateChanged;
            _sdkApi.DataReceived -= SdkApi_DataReceived;
            _sdkApi.DeviceStatusNotificationReceived -= SdkApi_DeviceStatusNotificationReceived;
            _sdkApi.Dispose();
        }

        private void MenuItemEegWaveform_Click(object sender, EventArgs e)
        {
            var waveformForm = new EegWaveformForm(_sdkApi);
            waveformForm.Show();
            waveformForm.StartDisplay();
        }

        private async void BtnNoiseReductionOff_Click(object sender, EventArgs e)
        {
            Log("Sending noise reduction off command...");
            bool success = await _sdkApi.SetNoiseReductionModeAsync(0);
            if (success)
            {
                Log("Noise reduction off command sent successfully");
            }
            else
            {
                Log("Failed to send noise reduction off command");
            }
        }

        private async void BtnNoiseReductionOn_Click(object sender, EventArgs e)
        {
            Log("Sending noise reduction on command...");
            bool success = await _sdkApi.SetNoiseReductionModeAsync(1);
            if (success)
            {
                Log("Noise reduction on command sent successfully");
            }
            else
            {
                Log("Failed to send noise reduction on command");
            }
        }

        private async void BtnEnvironmentalSound_Click(object sender, EventArgs e)
        {
            Log("Sending environmental sound command...");
            bool success = await _sdkApi.SetNoiseReductionModeAsync(2);
            if (success)
            {
                Log("Environmental sound command sent successfully");
            }
            else
            {
                Log("Failed to send environmental sound command");
            }
        }

        private async void BtnTouchOn_Click(object sender, EventArgs e)
        {
            Log("Sending touch on command...");
            bool success = await _sdkApi.SetTouchEnabledAsync(true);
            if (success)
            {
                Log("Touch on command sent successfully");
            }
            else
            {
                Log("Failed to send touch on command");
            }
        }

        private async void BtnTouchOff_Click(object sender, EventArgs e)
        {
            Log("Sending touch off command...");
            bool success = await _sdkApi.SetTouchEnabledAsync(false);
            if (success)
            {
                Log("Touch off command sent successfully");
            }
            else
            {
                Log("Failed to send touch off command");
            }
        }

        private async void BtnAutoPlayOn_Click(object sender, EventArgs e)
        {
            Log("Sending auto play on command...");
            bool success = await _sdkApi.SetAutoPlayEnabledAsync(true);
            if (success)
            {
                Log("Auto play on command sent successfully");
            }
            else
            {
                Log("Failed to send auto play on command");
            }
        }

        private async void BtnAutoPlayOff_Click(object sender, EventArgs e)
        {
            Log("Sending auto play off command...");
            bool success = await _sdkApi.SetAutoPlayEnabledAsync(false);
            if (success)
            {
                Log("Auto play off command sent successfully");
            }
            else
            {
                Log("Failed to send auto play off command");
            }
        }

        private void MenuItemAbout_Click(object sender, EventArgs e)
        {
            // Get real SDK version from SDK API
            string sdkVersion = "Unknown";
            try
            {
                if (_sdkApi != null)
                {
                    sdkVersion = _sdkApi.GetSdkVersion();
                }
                else
                {
                    sdkVersion = "SDK not initialized";
                }
            }
            catch (Exception ex)
            {
                sdkVersion = "Error: " + ex.Message;
            }

            string message = $"Naoyun SDK Version: {sdkVersion}\n\n" +
                           "Shanghai Naoyun Technology Co., Ltd.\n\n" +
                           "All rights reserved\n\n" +
                           "© 2026 Shanghai Naoyun Technology Co., Ltd.";
            MessageBox.Show(message, "About SDK", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SdkApi_SpectrumDataReceived(object sender, SpectrumDataEventArgs e)
        {
            // Handle spectrum data received event
            Log($"Received spectrum data - Left Signal Quality: {e.LeftSignalQuality}, Right Signal Quality: {e.RightSignalQuality}");
        }

        private void SdkApi_SpectrumTaskStatusChanged(object sender, SpectrumTaskStatusEventArgs e)
        {
            // Handle spectrum task status changed event    
            //string status = e.IsSuccess ? "Success" : "Failed";
            //Log($"Task status: {status} - {e.Message}");
        }

        private void SdkApi_ServerAuthCompleted(object sender, ServerAuthResultEventArgs e)
        {
            string status = e.IsSuccess ? "Success" : "Failed";
            Log($"Server auth: {status}, Permissions: {e.Permission}, BoundAt: {e.BoundAt}, LastSeen: {e.LastSeen}");
        }

        private void SdkApi_MentalStateDataReceived(object sender, MentalStateDataEventArgs e)
        {
            Log($"Mental state - Focus: {e.Focus:F2}, Fatigue: {e.Fatigue:F2}, Relax: {e.Relax:F2}, Calm: {e.Calm:F2}, Stress: {e.Stress:F2}");
        }
    }
}