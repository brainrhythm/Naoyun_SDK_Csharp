using NaoyunSdk.Interfaces;
using NaoyunSdk.Impl;
using System;

namespace NaoyunSdkSample.Services
{
    public class SdkService
    {
        private static SdkService _instance;
        private INaoyunSdkApi _sdkApi;

        //private string accessKeyId = "your accessKeyId";
        //private string accessKeySecret = "your accessKeySecret";

        private SdkService()
        {
            InitializeSdk();
        }

        public static SdkService Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new SdkService();
                }
                return _instance;
            }
        }

        public INaoyunSdkApi SdkApi
        {
            get { return _sdkApi; }
        }

        private void InitializeSdk()
        {
            try
            {
                _sdkApi = new NaoyunSdkApi();
                _sdkApi.Initialize(accessKeyId, accessKeySecret, true);
                Console.WriteLine("SDK initialized successfully");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"SDK initialization failed: {ex.Message}");
                throw;
            }
        }

        public void Dispose()
        {
            // 在这里可以添加清理资源的代码
            _instance = null;
        }
    }
}